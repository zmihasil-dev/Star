package android.view;
public abstract class Window { public abstract View getDecorView(); public void setBackgroundDrawable(android.graphics.drawable.Drawable d){} public void setLayout(int w,int h){} public void setSoftInputMode(int m){} }
