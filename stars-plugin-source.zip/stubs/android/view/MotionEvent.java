package android.view;
public class MotionEvent { public static final int ACTION_DOWN=0,ACTION_UP=1,ACTION_MOVE=2,ACTION_CANCEL=3;
 public int getActionMasked(){return 0;} public float getX(){return 0;} public float getY(){return 0;} }
