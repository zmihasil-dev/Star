package android.view;
import android.graphics.Canvas;
public class View {
  public CharSequence getContentDescription(){return null;} public boolean isSelected(){return false;} public int getLeft(){return 0;} public int getTop(){return 0;}
  public View(android.content.Context c){}
  public android.content.Context getContext(){return null;}
  public int getWidth(){return 0;} public int getHeight(){return 0;}
  public ViewParent getParent(){return null;}
  public void bringToFront(){} public void invalidate(){}
  public void setWillNotDraw(boolean b){}
  public boolean removeCallbacks(Runnable r){return false;}
  public void postOnAnimation(Runnable r){}
  public android.content.res.Resources getResources(){return null;}
  public boolean performHapticFeedback(int i){return false;}
  protected void onSizeChanged(int w,int h,int ow,int oh){}
  protected void onAttachedToWindow(){} protected void onDetachedFromWindow(){}
  protected void onDraw(Canvas c){}
  public boolean isShown(){return true;} public void getLocationOnScreen(int[] l){} public int getVisibility(){return 0;} public void setBackground(android.graphics.drawable.Drawable d){} public void setPadding(int a,int b,int c,int d){} public void setOnClickListener(OnClickListener l){} public boolean post(Runnable r){return true;}
  public interface OnClickListener { void onClick(View v); }
  public boolean onTouchEvent(MotionEvent e){return false;}
}
