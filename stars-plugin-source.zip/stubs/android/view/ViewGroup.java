package android.view;
public abstract class ViewGroup extends View implements ViewParent {
  public ViewGroup(android.content.Context c){super(c);}
  public static class LayoutParams { public static final int WRAP_CONTENT=-2;  public static final int MATCH_PARENT=-1; public LayoutParams(int w,int h){} }
  public int getChildCount(){return 0;} public View getChildAt(int i){return null;} public void addView(View v, LayoutParams p){} public void removeView(View v){}
  public void requestDisallowInterceptTouchEvent(boolean b){}
}
