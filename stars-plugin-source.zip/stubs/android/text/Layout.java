package android.text;
public abstract class Layout { public int getLineCount(){return 0;} public int getLineTop(int l){return 0;} public int getLineBottom(int l){return 0;} public float getLineRight(int l){return 0;} }
