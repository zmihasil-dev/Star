package android.graphics;
public class Canvas { public Canvas(){} public Canvas(Bitmap b){} public int save(){return 0;} public void restore(){} public void translate(float x,float y){} public void scale(float x,float y){} public void rotate(float d){}
 public void drawPath(Path p,Paint q){} public void drawCircle(float x,float y,float r,Paint p){} public void drawOval(RectF r,Paint p){} public void drawRect(float l,float t,float r,float b,Paint p){}
 public void drawRect(RectF r,Paint p){} public void drawRoundRect(RectF r,float rx,float ry,Paint p){} public void drawLine(float a,float b,float c,float d,Paint p){}
 public void drawText(String s,float x,float y,Paint p){} public void drawArc(RectF r,float a,float b,boolean u,Paint p){} public boolean clipPath(Path p){return true;} }
