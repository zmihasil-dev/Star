package android.graphics;
public class BitmapShader extends Shader { public BitmapShader(Bitmap b,Shader.TileMode x,Shader.TileMode y){} }
