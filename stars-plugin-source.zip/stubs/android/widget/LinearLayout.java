package android.widget;
public class LinearLayout extends android.view.ViewGroup { public static final int HORIZONTAL=0,VERTICAL=1; public LinearLayout(android.content.Context c){super(c);} public void setOrientation(int o){} public void setGravity(int g){}
 public static class LayoutParams extends android.view.ViewGroup.LayoutParams { public LayoutParams(int w,int h){super(w,h);} public LayoutParams(int w,int h,float wt){super(w,h);} public void setMargins(int a,int b,int c,int d){} } }
