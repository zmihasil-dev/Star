package android.widget;
public class Toast { public static final int LENGTH_LONG=1; public static final int LENGTH_SHORT=0; public static Toast makeText(android.content.Context c,CharSequence s,int d){return null;} public void show(){} }
