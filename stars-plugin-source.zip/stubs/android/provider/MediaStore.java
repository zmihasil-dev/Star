package android.provider;
public class MediaStore { public static class Images { public static class Media { public static final android.net.Uri EXTERNAL_CONTENT_URI=null; public static final String _ID="_id"; public static final String DATE_ADDED="date_added"; } } }
