package cat.narezany.margyt.plugin;
public class PluginContext {
  public android.content.Context context(){return null;}
  public void log(String s){}
  public android.content.SharedPreferences prefs(){return null;}
}
