package stars.margyt;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.os.SystemClock;
import android.text.Layout;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import java.lang.ref.WeakReference;
import java.util.ArrayList;

/**
 * Прозрачный слой поверх приложения: следит за кнопкой лайка, считает лайки (1 лайк = 1 звезда),
 * рисует звёзды и звание рядом с ником и маленькую кнопку статистики. Касания проходят в приложение,
 * кроме самой кнопки.
 */
final class StarsView extends View {

    interface Logger {
        void log(String s);
    }

    /** Кнопка лайка, за которой следим. */
    private static final class Watch {
        final WeakReference<View> ref;
        boolean sel;
        int px, py;
        int stable;
        long settleUntil;

        Watch(View v, boolean sel, int px, int py) {
            this.ref = new WeakReference<View>(v);
            this.sel = sel;
            this.px = px;
            this.py = py;
        }
    }

    private static final class Fly {
        float x, y, vx, vy, rot, size;
        long born;
        int life;
    }

    private final StarsStore store;
    private final Logger logger;
    private final float dp;
    private final int slop;

    private final ArrayList<WeakReference<TextView>> nicks = new ArrayList<WeakReference<TextView>>();
    private final ArrayList<Watch> watches = new ArrayList<Watch>();
    private final ArrayList<Fly> flies = new ArrayList<Fly>();
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rect = new RectF();
    private final int[] loc = new int[2];
    private final int[] own = new int[2];
    private final int[] tmp = new int[2];

    private Activity activity;
    private boolean running, drawFailed;
    private long lastScan;
    private long bannerStart;
    private int bannerRank;
    private long pulseStart;

    // кнопка
    private float bx = -1f, by = -1f;
    private final float br;
    private boolean downOnBtn, dragging;
    private float downX, downY, offX, offY;

    private final Runnable stepper = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            step();
            postOnAnimation(this);
        }
    };

    StarsView(Context context, StarsStore store, Logger logger) {
        super(context);
        this.store = store;
        this.logger = logger;
        this.dp = context.getResources().getDisplayMetrics().density;
        this.slop = ViewConfiguration.get(context).getScaledTouchSlop();
        this.br = 19f * dp;
        setWillNotDraw(false);
        line.setStyle(Paint.Style.STROKE);
        text.setTextAlign(Paint.Align.CENTER);
        text.setFakeBoldText(true);
    }

    void setActivity(Activity a) {
        activity = a;
    }

    void clearActivity(Activity a) {
        if (activity == a) activity = null;
        watches.clear();
    }

    void destroy() {
        running = false;
        removeCallbacks(stepper);
        nicks.clear();
        watches.clear();
        flies.clear();
    }

    /** Вызывается после изменения настроек. */
    void refresh() {
        nicks.clear();
        lastScan = 0L;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        if (bx < 0f) {
            bx = 8f * dp + br;
            by = h * 0.22f;
        }
        bx = clamp(bx, br, w - br);
        by = clamp(by, br, h - br);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = true;
        removeCallbacks(stepper);
        postOnAnimation(stepper);
    }

    @Override
    protected void onDetachedFromWindow() {
        running = false;
        removeCallbacks(stepper);
        super.onDetachedFromWindow();
    }

    // ------------------------------------------------------------ сканирование

    private void step() {
        try {
            long now = SystemClock.uptimeMillis();
            if (now - lastScan > 100) {
                lastScan = now;
                ViewParent p = getParent();
                if (p instanceof View) {
                    ArrayList<WeakReference<TextView>> foundNicks = new ArrayList<WeakReference<TextView>>();
                    ArrayList<View> likeBtns = new ArrayList<View>();
                    collect((View) p, 0, StarsStore.norm(store.username), foundNicks, likeBtns);
                    nicks.clear();
                    nicks.addAll(foundNicks);
                    updateWatches(likeBtns, now);
                }
            }
            invalidate();
        } catch (Throwable t) {
            safeLog("stars: step failed: " + t);
        }
    }

    private static boolean isLikeDesc(CharSequence cd) {
        if (cd == null || cd.length() == 0 || cd.length() > 90) return false;
        String s = cd.toString().toLowerCase();
        return s.contains("like") || s.contains("лайк") || s.contains("нравится") || s.contains("понрав");
    }

    private static boolean isUnlikeState(CharSequence cd) {
        String s = cd.toString().toLowerCase();
        return s.contains("unlike") || s.contains("remove like") || s.contains("liked")
                || s.contains("убрать") || s.contains("отмен");
    }

    private void collect(View v, int depth, String u, ArrayList<WeakReference<TextView>> outNicks,
                         ArrayList<View> outLikes) {
        if (v == this || depth > 70) return;
        if (v.getVisibility() != 0) return;
        if (v instanceof TextView) {
            if (u.length() > 0) {
                CharSequence t = ((TextView) v).getText();
                if (t != null && t.length() > 0 && t.length() <= 80
                        && StarsStore.norm(t).equals(u)) {
                    outNicks.add(new WeakReference<TextView>((TextView) v));
                }
            }
        } else {
            CharSequence cd = v.getContentDescription();
            if (isLikeDesc(cd)) {
                int w = v.getWidth(), h = v.getHeight();
                if (w >= 16f * dp && h >= 16f * dp && w <= 130f * dp && h <= 130f * dp
                        && v.isShown()) {
                    outLikes.add(v);
                }
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            int n = g.getChildCount();
            for (int i = 0; i < n; i++) collect(g.getChildAt(i), depth + 1, u, outNicks, outLikes);
        }
    }

    private static boolean liked(View v) {
        CharSequence cd = v.getContentDescription();
        return v.isSelected() || (cd != null && isUnlikeState(cd));
    }

    private void updateWatches(ArrayList<View> btns, long now) {
        // выкидываем исчезнувшие
        for (int i = watches.size() - 1; i >= 0; i--) {
            View v = watches.get(i).ref.get();
            if (v == null || !btns.contains(v)) watches.remove(i);
        }
        for (int i = 0; i < btns.size(); i++) {
            View v = btns.get(i);
            v.getLocationOnScreen(tmp);
            int px = tmp[0], py = tmp[1];
            boolean sel = liked(v);
            Watch w = null;
            for (int k = 0; k < watches.size(); k++) {
                if (watches.get(k).ref.get() == v) {
                    w = watches.get(k);
                    break;
                }
            }
            if (w == null) {
                w = new Watch(v, sel, px, py);
                w.settleUntil = now + 700;
                watches.add(w);
                continue;
            }
            boolean moved = Math.abs(px - w.px) > 2 || Math.abs(py - w.py) > 2;
            if (moved) {
                w.stable = 0;
                w.settleUntil = now + 700; // идёт прокрутка / смена видео — состояние не считаем
            } else if (w.stable < 1000) {
                w.stable++;
            }
            w.px = px;
            w.py = py;
            if (sel != w.sel) {
                boolean calm = !moved && w.stable >= 2 && now >= w.settleUntil;
                w.sel = sel;
                if (calm) {
                    if (sel) onLike(v, px, py);
                    else onUnlike();
                }
            }
        }
    }

    private void onLike(View v, int px, int py) {
        int before = store.rank();
        store.likes++;
        store.saveAll();
        pulseStart = SystemClock.uptimeMillis();
        getLocationOnScreen(own);
        spawnStar(px - own[0] + v.getWidth() / 2f, py - own[1] + v.getHeight() / 2f);
        int after = store.rank();
        if (after > before && after > store.celebrated) {
            store.celebrated = after;
            store.saveAll();
            bannerRank = after;
            bannerStart = SystemClock.uptimeMillis();
            for (int i = 0; i < 26; i++) spawnStar(getWidth() / 2f, getHeight() * 0.3f);
            try {
                performHapticFeedback(0);
            } catch (Throwable ignored) {
            }
        }
    }

    private void onUnlike() {
        // чтобы нельзя было накручивать лайк/анлайк, забираем звезду обратно
        if (store.likes > 0) {
            store.likes--;
            store.saveAll();
        }
    }

    private void spawnStar(float x, float y) {
        if (flies.size() > 60) return;
        Fly f = new Fly();
        f.x = x;
        f.y = y;
        double a = Math.random() * Math.PI * 2.0;
        float sp = (1.5f + (float) Math.random() * 4.5f) * dp;
        f.vx = (float) Math.cos(a) * sp;
        f.vy = (float) Math.sin(a) * sp - 3f * dp;
        f.rot = (float) (Math.random() * 6.28);
        f.size = (6f + (float) Math.random() * 8f) * dp;
        f.born = SystemClock.uptimeMillis();
        f.life = 900 + (int) (Math.random() * 500);
        flies.add(f);
    }

    // ------------------------------------------------------------ касания

    private boolean hitButton(float x, float y) {
        float rr = br + 10f * dp;
        float dx = x - bx, dy = y - by;
        return dx * dx + dy * dy <= rr * rr;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        try {
            int a = e.getActionMasked();
            float x = e.getX(), y = e.getY();
            if (a == MotionEvent.ACTION_DOWN) {
                downOnBtn = hitButton(x, y);
                if (downOnBtn) {
                    dragging = false;
                    downX = x;
                    downY = y;
                    offX = bx - x;
                    offY = by - y;
                    ViewParent p = getParent();
                    if (p != null) p.requestDisallowInterceptTouchEvent(true);
                }
                return downOnBtn;
            }
            if (!downOnBtn) return false;
            if (a == MotionEvent.ACTION_MOVE) {
                if (!dragging) {
                    float dx = x - downX, dy = y - downY;
                    if (Math.sqrt(dx * dx + dy * dy) > slop * 1.5f) dragging = true;
                }
                if (dragging) {
                    bx = clamp(x + offX, br, getWidth() - br);
                    by = clamp(y + offY, br, getHeight() - br);
                }
                return true;
            }
            if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) {
                downOnBtn = false;
                boolean tap = a == MotionEvent.ACTION_UP && !dragging;
                dragging = false;
                if (tap) openStats();
                return true;
            }
            return true;
        } catch (Throwable t) {
            safeLog("stars: touch failed: " + t);
            return false;
        }
    }

    private void openStats() {
        Activity a = activity;
        if (a == null) return;
        try {
            StarsUi.show(a, store, this);
        } catch (Throwable t) {
            safeLog("stars: dialog failed: " + t);
        }
    }

    // ------------------------------------------------------------ рисование

    @Override
    protected void onDraw(Canvas c) {
        try {
            drawNickChips(c);
            drawButton(c);
            drawFlies(c);
            drawBanner(c);
        } catch (Throwable t) {
            if (!drawFailed) {
                drawFailed = true;
                safeLog("stars: draw failed: " + t);
            }
        }
    }

    private void star(Canvas c, float cx, float cy, float r, float rot, int color) {
        path.reset();
        for (int k = 0; k < 10; k++) {
            float a = (float) (rot - Math.PI / 2.0 + k * Math.PI / 5.0);
            float rr = (k % 2 == 0) ? r : r * 0.43f;
            float px = cx + (float) Math.cos(a) * rr, py = cy + (float) Math.sin(a) * rr;
            if (k == 0) path.moveTo(px, py);
            else path.lineTo(px, py);
        }
        path.close();
        fill.setShader(null);
        fill.setColor(color);
        c.drawPath(path, fill);
    }

    private static int rankColor(int rank) {
        return rank >= 2 ? 0xFFB07CFF : (rank == 1 ? 0xFFFFD34D : 0xFFE8E8EE);
    }

    private void drawNickChips(Canvas c) {
        if (nicks.isEmpty()) return;
        getLocationOnScreen(own);
        float w = getWidth(), h = getHeight();
        long n = store.stars();
        int rank = store.rank();
        String label = StarsStore.group(n) + (rank > 0 ? "  " + StarsStore.rankName(rank) : "");
        for (int i = nicks.size() - 1; i >= 0; i--) {
            TextView tv = nicks.get(i).get();
            if (tv == null || !tv.isShown() || tv.getWidth() <= 0) {
                nicks.remove(i);
                continue;
            }
            Layout lay = tv.getLayout();
            if (lay == null || lay.getLineCount() == 0) continue;
            tv.getLocationOnScreen(loc);
            float ts = clamp(tv.getTextSize(), 11f * dp, 22f * dp);
            float cy = loc[1] - own[1] + tv.getExtendedPaddingTop()
                    + (lay.getLineTop(0) + lay.getLineBottom(0)) / 2f;
            float left = loc[0] - own[0] + tv.getCompoundPaddingLeft() + lay.getLineRight(0) + 4f * dp;
            Drawable[] cd = tv.getCompoundDrawables();
            if (cd != null && cd[2] != null) left += cd[2].getBounds().width() + 2f * dp;
            text.setTextSize(ts * 0.78f);
            float tw = text.measureText(label);
            float chipH = ts * 1.25f;
            float chipW = chipH * 0.95f + tw + 6f * dp;
            if (left < 0f || left + chipW > w || cy < 0f || cy > h) {
                // не влезает справа — ставим под ником
                left = loc[0] - own[0] + tv.getCompoundPaddingLeft();
                cy += chipH * 1.1f;
                if (left < 0f || left + chipW > w || cy < 0f || cy > h) continue;
            }
            rect.set(left, cy - chipH / 2f, left + chipW, cy + chipH / 2f);
            fill.setShader(null);
            fill.setColor(0xCC15161C);
            c.drawRoundRect(rect, chipH / 2f, chipH / 2f, fill);
            line.setStrokeWidth(1.2f * dp);
            line.setColor(rankColor(rank));
            c.drawRoundRect(rect, chipH / 2f, chipH / 2f, line);
            star(c, left + chipH * 0.55f, cy, chipH * 0.33f, 0f, rankColor(rank));
            text.setColor(0xFFFFFFFF);
            text.setTextAlign(Paint.Align.LEFT);
            c.drawText(label, left + chipH * 0.95f, cy + ts * 0.27f, text);
            text.setTextAlign(Paint.Align.CENTER);
        }
    }

    private void drawButton(Canvas c) {
        if (bx < 0f) return;
        long now = SystemClock.uptimeMillis();
        float pulse = 0f;
        long dt = now - pulseStart;
        if (dt >= 0 && dt < 350) pulse = 1f - dt / 350f;
        float r = br * (1f + 0.25f * pulse);
        fill.setShader(null);
        fill.setColor(0xB0202330);
        c.drawCircle(bx, by, r, fill);
        line.setStrokeWidth(1.4f * dp);
        line.setColor(rankColor(store.rank()));
        c.drawCircle(bx, by, r, line);
        star(c, bx, by - r * 0.18f, r * 0.55f, 0f, rankColor(store.rank()) == 0xFFE8E8EE ? 0xFFFFD34D : rankColor(store.rank()));
        text.setTextSize(9f * dp);
        text.setColor(0xFFFFFFFF);
        String s = StarsStore.rank(store.stars());
        c.drawText(s, bx, by + r * 0.78f, text);
    }

    private void drawFlies(Canvas c) {
        if (flies.isEmpty()) return;
        long now = SystemClock.uptimeMillis();
        for (int i = flies.size() - 1; i >= 0; i--) {
            Fly f = flies.get(i);
            long age = now - f.born;
            if (age > f.life) {
                flies.remove(i);
                continue;
            }
            f.x += f.vx;
            f.y += f.vy;
            f.vy += 0.18f * dp;
            f.vx *= 0.985f;
            float k = 1f - (float) age / f.life;
            int alpha = (int) (255 * k);
            star(c, f.x, f.y, f.size * (0.6f + 0.4f * k), f.rot + age * 0.006f,
                    (alpha << 24) | 0x00FFD34D);
        }
    }

    private void drawBanner(Canvas c) {
        if (bannerRank <= 0) return;
        long dt = SystemClock.uptimeMillis() - bannerStart;
        if (dt > 3200) {
            bannerRank = 0;
            return;
        }
        float in = Math.min(1f, dt / 350f);
        float out = dt > 2700 ? 1f - (dt - 2700) / 500f : 1f;
        float a = Math.max(0f, Math.min(in, out));
        float w = getWidth();
        float cy = getHeight() * 0.18f + (1f - in) * -20f * dp;
        float bw = Math.min(w - 40f * dp, 300f * dp), bh = 64f * dp;
        rect.set(w / 2f - bw / 2f, cy - bh / 2f, w / 2f + bw / 2f, cy + bh / 2f);
        fill.setShader(null);
        fill.setColor(((int) (230 * a) << 24) | 0x00181A24);
        c.drawRoundRect(rect, 18f * dp, 18f * dp, fill);
        line.setStrokeWidth(2f * dp);
        line.setColor(((int) (255 * a) << 24) | (rankColor(bannerRank) & 0xFFFFFF));
        c.drawRoundRect(rect, 18f * dp, 18f * dp, line);
        star(c, rect.left + 34f * dp, cy, 18f * dp, (float) (dt * 0.004), rankColor(bannerRank));
        text.setTextAlign(Paint.Align.LEFT);
        text.setColor(((int) (255 * a) << 24) | 0x00FFFFFF);
        text.setTextSize(12f * dp);
        c.drawText("Новое звание!", rect.left + 62f * dp, cy - 5f * dp, text);
        text.setTextSize(19f * dp);
        text.setColor(((int) (255 * a) << 24) | (rankColor(bannerRank) & 0xFFFFFF));
        c.drawText(StarsStore.rankName(bannerRank), rect.left + 62f * dp, cy + 17f * dp, text);
        text.setTextAlign(Paint.Align.CENTER);
    }

    private void safeLog(String s) {
        try {
            logger.log(s);
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float v, float lo, float hi) {
        return v < lo ? lo : (v > hi ? hi : v);
    }
}
