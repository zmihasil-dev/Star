package stars.margyt;

import android.app.Activity;
import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.FrameLayout;

import cat.narezany.margyt.plugin.MargyPlugin;
import cat.narezany.margyt.plugin.PluginContext;

/** Звёзды за лайки: считает лайки с твоего профиля, показывает звёзды и звание рядом с ником (только на этом телефоне). */
public final class StarsPlugin extends MargyPlugin {

    private Handler main;
    private PluginContext pc;
    private StarsView view;

    @Override
    public void onStart(Context context) {
        final Context ctx = context;
        try {
            pc = margyt();
        } catch (Throwable ignored) {
        }
        main = new Handler(Looper.getMainLooper());
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    android.content.SharedPreferences prefs = null;
                    try {
                        prefs = pc.prefs();
                    } catch (Throwable ignored) {
                    }
                    StarsStore store = new StarsStore(prefs);
                    view = new StarsView(ctx, store, new StarsView.Logger() {
                        @Override
                        public void log(String s) {
                            safeLog(s);
                        }
                    });
                    safeLog("stars: started");
                } catch (Throwable t) {
                    safeLog("stars: start failed: " + t);
                }
            }
        });
    }

    @Override
    public void onActivityResumed(final Activity activity) {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                attach(activity);
            }
        });
    }

    @Override
    public void onActivityPaused(final Activity activity) {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                detach(activity);
            }
        });
    }

    @Override
    public void onStop() {
        if (main == null) return;
        main.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (view != null) {
                        removeFromParent();
                        view.destroy();
                        view = null;
                    }
                } catch (Throwable t) {
                    safeLog("stars: stop failed: " + t);
                }
            }
        });
    }

    private void attach(Activity activity) {
        try {
            if (view == null) return;
            view.setActivity(activity);
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            if (view.getParent() == decor) {
                view.bringToFront();
                return;
            }
            removeFromParent();
            decor.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT));
            view.bringToFront();
        } catch (Throwable t) {
            safeLog("stars: attach failed: " + t);
        }
    }

    private void detach(Activity activity) {
        try {
            if (view == null) return;
            view.clearActivity(activity);
            ViewGroup decor = (ViewGroup) activity.getWindow().getDecorView();
            if (view.getParent() == decor) {
                decor.removeView(view);
            }
        } catch (Throwable t) {
            safeLog("stars: detach failed: " + t);
        }
    }

    private void safeLog(String s) {
        try {
            if (pc != null) pc.log(s);
        } catch (Throwable ignored) {
        }
    }

    private void removeFromParent() {
        ViewParent p = view.getParent();
        if (p instanceof ViewGroup) {
            ((ViewGroup) p).removeView(view);
        }
    }
}
