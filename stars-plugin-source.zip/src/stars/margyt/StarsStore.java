package stars.margyt;

import android.content.SharedPreferences;

import java.util.Locale;

/** Лайки, звёзды и звание. Всё хранится только на этом телефоне. */
final class StarsStore {

    static final long STAR_AT = 100L;
    static final long LIGHT_AT = 1000L;

    private final SharedPreferences prefs; // может быть null — тогда данные живут до перезапуска
    String username = "";
    long likes;        // последнее значение, считанное с твоего профиля
    long manual;       // ручной ввод на случай, если автоматически не считалось
    int celebrated;    // звание, для которого уже показали поздравление

    StarsStore(SharedPreferences prefs) {
        this.prefs = prefs;
        try {
            if (prefs != null) {
                username = prefs.getString("username", "");
                likes = prefs.getLong("likes", 0L);
                manual = prefs.getLong("manual", 0L);
                celebrated = prefs.getInt("celebrated", 0);
            }
        } catch (Throwable ignored) {
        }
    }

    /** Звёзды: одна за каждый лайк. */
    long stars() {
        return likes;
    }

    static int rankFor(long n) {
        return n >= LIGHT_AT ? 2 : (n >= STAR_AT ? 1 : 0);
    }

    int rank() {
        return rankFor(stars());
    }

    /** Короткая подпись для кнопки: число звёзд. */
    static String rank(long n) {
        return n >= 10000 ? (n / 1000) + "k" : Long.toString(n);
    }

    static String rankName(int r) {
        return r >= 2 ? "starlight" : (r == 1 ? "star" : "");
    }

    /** Сколько звёзд нужно до следующего звания (0 — уже максимальное). */
    static long nextGoal(long n) {
        return n < STAR_AT ? STAR_AT : (n < LIGHT_AT ? LIGHT_AT : 0L);
    }

    void saveAll() {
        try {
            if (prefs != null) {
                prefs.edit().putString("username", username).putLong("likes", likes)
                        .putLong("manual", manual).putInt("celebrated", celebrated).apply();
            }
        } catch (Throwable ignored) {
        }
    }

    static String norm(CharSequence s) {
        if (s == null) return "";
        String t = s.toString().trim().toLowerCase(Locale.US);
        while (t.startsWith("@")) t = t.substring(1);
        return t.trim();
    }

    /** 1234 → "1 234" */
    static String group(long n) {
        String s = Long.toString(n);
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            if (i > 0 && (s.length() - i) % 3 == 0) b.append(' ');
            b.append(s.charAt(i));
        }
        return b.toString();
    }

    /**
     * Разбирает число из статистики профиля: "123", "1,234", "12.3K", "12,3 тыс.", "1.2M".
     * @return значение или -1, если это не число
     */
    static long parseCount(CharSequence cs) {
        if (cs == null) return -1L;
        String s = cs.toString().trim().toLowerCase(Locale.US).replace(' ', ' ').replace(' ', ' ');
        if (s.length() == 0 || s.length() > 14) return -1L;
        double mult = 1.0;
        String core = s;
        if (s.endsWith("млрд")) {
            mult = 1e9;
            core = s.substring(0, s.length() - 4);
        } else if (s.endsWith("млн")) {
            mult = 1e6;
            core = s.substring(0, s.length() - 3);
        } else if (s.endsWith("тыс.")) {
            mult = 1e3;
            core = s.substring(0, s.length() - 4);
        } else if (s.endsWith("тыс")) {
            mult = 1e3;
            core = s.substring(0, s.length() - 3);
        } else {
            char last = s.charAt(s.length() - 1);
            if (last == 'k' || last == 'к') {
                mult = 1e3;
                core = s.substring(0, s.length() - 1);
            } else if (last == 'm' || last == 'м') {
                mult = 1e6;
                core = s.substring(0, s.length() - 1);
            } else if (last == 'b') {
                mult = 1e9;
                core = s.substring(0, s.length() - 1);
            }
        }
        core = core.trim();
        if (core.length() == 0) return -1L;
        for (int i = 0; i < core.length(); i++) {
            char ch = core.charAt(i);
            if (!((ch >= '0' && ch <= '9') || ch == ',' || ch == '.' || ch == ' ')) return -1L;
        }
        try {
            if (mult > 1.0) {
                double d = Double.parseDouble(core.replace(" ", "").replace(',', '.'));
                return Math.round(d * mult);
            }
            String digits = core.replace(" ", "").replace(",", "").replace(".", "");
            if (digits.length() == 0 || digits.length() > 12) return -1L;
            return Long.parseLong(digits);
        } catch (Throwable t) {
            return -1L;
        }
    }
}
