package stars.margyt;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/** Окно статистики (рисуется кодом, ресурсов в плагине нет). */
final class StarsUi {

    private StarsUi() {
    }

    private static GradientDrawable round(int color, float radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        return g;
    }

    private static TextView label(Activity a, String text, float sp, int color) {
        TextView t = new TextView(a);
        t.setText(text);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private static TextView button(Activity a, String text, int bg, float dp) {
        TextView t = label(a, text, 15f, 0xFFFFFFFF);
        t.setGravity(17);
        t.setPadding((int) (14 * dp), (int) (11 * dp), (int) (14 * dp), (int) (11 * dp));
        t.setBackground(round(bg, 12 * dp));
        return t;
    }

    private static EditText field(Activity a, String hint, String value, float dp) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextColor(0xFFFFFFFF);
        e.setHintTextColor(0xFF8A8D99);
        e.setTextSize(16f);
        e.setPadding((int) (12 * dp), (int) (10 * dp), (int) (12 * dp), (int) (10 * dp));
        e.setBackground(round(0xFF2B2D36, 10 * dp));
        return e;
    }

    private static LinearLayout.LayoutParams lp(int w, int h, int top, float dp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(0, (int) (top * dp), 0, 0);
        return p;
    }

    static void show(final Activity a, final StarsStore store, final StarsView owner) {
        final float dp = a.getResources().getDisplayMetrics().density;
        final Dialog d = new Dialog(a);
        final int pad = (int) (18 * dp);
        final int W = ViewGroup.LayoutParams.MATCH_PARENT, H = ViewGroup.LayoutParams.WRAP_CONTENT;

        LinearLayout box = new LinearLayout(a);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(pad, pad, pad, pad);
        box.setBackground(round(0xFF1E1F26, 18 * dp));

        long n = store.stars();
        int rank = store.rank();
        box.addView(label(a, "★ Звёзды за лайки", 21f, 0xFFFFFFFF), lp(W, H, 0, dp));
        box.addView(label(a, "1 лайк = 1 звезда. 100 звёзд — звание star, 1000 и больше — starlight. "
                + "Звёзды и звание видны только на этом телефоне.", 13f, 0xFF9DA0AE), lp(W, H, 4, dp));

        box.addView(label(a, StarsStore.group(n) + " ★", 34f, 0xFFFFD34D), lp(W, H, 14, dp));
        String title = rank == 0 ? "Звания пока нет" : "Звание: " + StarsStore.rankName(rank);
        box.addView(label(a, title, 17f, rank >= 2 ? 0xFFB07CFF : 0xFFFFFFFF), lp(W, H, 2, dp));
        long goal = StarsStore.nextGoal(n);
        if (goal > 0) {
            String next = goal == StarsStore.STAR_AT ? "star" : "starlight";
            box.addView(label(a, "До звания " + next + ": " + StarsStore.group(goal - n), 13f, 0xFFB8BBC8),
                    lp(W, H, 4, dp));
        } else {
            box.addView(label(a, "Максимальное звание получено!", 13f, 0xFFB8BBC8), lp(W, H, 4, dp));
        }

        box.addView(label(a, "Твой ник (без @) — рядом с ним рисуются звёзды", 13f, 0xFFB8BBC8), lp(W, H, 14, dp));
        final EditText user = field(a, "например, margyt", store.username, dp);
        box.addView(user, lp(W, H, 4, dp));

        box.addView(label(a, "Поправить число звёзд (если счётчик ошибся)", 13f, 0xFFB8BBC8), lp(W, H, 12, dp));
        final EditText count = field(a, "число", Long.toString(n), dp);
        box.addView(count, lp(W, H, 4, dp));

        TextView save = button(a, "Сохранить", 0xFF3D7BFF, dp);
        box.addView(save, lp(W, H, 14, dp));
        TextView close = button(a, "Закрыть", 0xFF2B2D36, dp);
        box.addView(close, lp(W, H, 8, dp));

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    store.username = StarsStore.norm(user.getText());
                    long c = StarsStore.parseCount(count.getText());
                    if (c >= 0L) {
                        long old = store.stars();
                        store.likes = c;
                        // если число вручную исправили — не поздравляем заново за уже полученное звание
                        if (store.rank() > store.celebrated) store.celebrated = store.rank();
                        if (c < old && store.rank() < store.celebrated) store.celebrated = store.rank();
                    }
                    store.saveAll();
                    owner.refresh();
                    Toast.makeText(a, "Сохранено", Toast.LENGTH_SHORT).show();
                } catch (Throwable ignored) {
                }
                d.dismiss();
            }
        });
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                d.dismiss();
            }
        });

        d.setContentView(box);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(0));
            w.setLayout((int) (a.getResources().getDisplayMetrics().widthPixels * 0.88f), H);
            w.setSoftInputMode(0x10);
        }
        d.show();
    }
}
